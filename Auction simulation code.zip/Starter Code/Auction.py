'''
Code to simulate the auction.
Successively loads all user-submitted files as modules, and calls the make_bid method.
'''

import importlib
import os
from Strategy import StrategyBase,StrategyHelper
from random import randint

class Auction:

    def __init__(self, strategy_folder, round_count, starting_capital,max_value,second_highest_fraction,type='self',tax = 0.0,log=False):
        # type can either be 'self': you get your own value, or 'max': you get max of all values
        self.__strategy_folder = strategy_folder # path where all strategy submissions are located
        self.round_count = round_count # number of rounds
        self.__round_number = 0
        self.starting_capital = starting_capital
        self.max_value = max_value
        self.type=type
        self.tax = tax
        self.__dead_strategies = 0
        self.log=log
        self.second_highest_fraction = second_highest_fraction
        self.__load_strategies(self.starting_capital,self.max_value)
        self.capitals = [starting_capital for strategy in self.__strategies]
        self.simulate()
    

    def __load_strategies(self,starting_capital,max_value):
        self.__strategies = []
        for file in os.listdir(self.__strategy_folder):
            if file.endswith('.py'):
                module_name = file[:-3]  # removes '.py' extension
                module = importlib.import_module(f"{self.__strategy_folder}.{module_name}")
                for attr in dir(module):
                    obj = getattr(module, attr)
                    if isinstance(obj, type) and issubclass(obj, StrategyBase) and obj is not StrategyBase:
                        self.__strategies.append(StrategyHelper(module_name,obj(),starting_capital,max_value,second_highest_fraction=self.second_highest_fraction,tax= self.tax,log=self.log))
    

    def __pick_from_distribution(self):
        # Picks a random number from distribution of our choice
        return randint(0,100)
    
    def __get_values(self):
        self.values = [self.__pick_from_distribution() for i in range(len(self.__strategies)) if self.__strategies[i].capital>0]
        return self.values
    
    def __get_bids(self):
        bids = []
        confidences = []
        for strategy, value in zip([s for s in self.__strategies if s.capital > 0], self.values):
            bid, confidence = strategy.bid(value, len(self.__strategies) - self.__dead_strategies)
            bids.append(bid)
            confidences.append(confidence)
        return bids, confidences

    def find_two_highest(self,nums):

        first, second = float('-inf'), float('-inf')

        for num in nums:
            if num > first:
                first, second = num, first
            elif num > second and num != first:
                second = num

        return first, second

    def run_auction(self):
        # Simulates 1 round of the auction
        self.__round_number += 1
        values = self.__get_values()
        bids, confidences = self.__get_bids()
        winning_bid,second_highest = self.find_two_highest(bids)
        if self.log: print(f"Top 2 bids are {winning_bid:0.2f},{second_highest:0.2f}")
        max_value = max(values)
        if winning_bid<0:
            print("SOMETHING WENT WRONG. ALl bots either made illegal bids, or are out of capital.")
            print("Bids from active bots: ",bids)
            print("Values obatined by active bots: ",values)
            print("Capitals remaining ", [strategy.capital for strategy in self.__strategies])
            return
        for strategy in self.__strategies:
            winning_value = max_value if self.type=='max' else strategy.value
            confidence = strategy.confidence
            if self.compare(strategy.bid_value,winning_bid):
                self.__dead_strategies += strategy.update_capital(winning_value,winning_bid,second_highest,confidence,winner=True)
            elif self.compare(strategy.bid_value,second_highest):
                self.__dead_strategies += strategy.update_capital(winning_value,winning_bid,second_highest,confidence,winner=False,second=True)
            else:
                self.__dead_strategies += strategy.update_capital(winning_value,winning_bid,second_highest,confidence)
        if len(self.__strategies)-self.__dead_strategies <=1: return -1
        else: return 0

    def compare(self,value1, value2, epsilon=0.001):
        return abs(value1-value2)<epsilon

    def simulate(self):
        while self.__round_number < self.round_count:
            status = self.run_auction()
            if status<0: break
