from Strategy import StrategyBase

class UserStrategy(StrategyBase):

    # Refer to Strategy.py for implementation details
    # Edit the function below without changing its template(name, input parameters, output type)
    def make_bid(self, current_value, previous_winners,previous_second_highest_bids,capital,num_bidders):
        # Example strategy: Bid a constnant amount = 50

        # return (50, 0.75) # return a tuple (bid, confidence) only for variant 2, where a confidence is also needed
        return 50 # return a single value (only bid) for variants 1 & 3, as confidence is not required here
       
        