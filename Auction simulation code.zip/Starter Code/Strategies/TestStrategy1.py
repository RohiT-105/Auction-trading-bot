from Strategy import StrategyBase

class UserStrategy(StrategyBase):

    def make_bid(self, current_value, previous_winners,previous_second_highest_bids,capital,num_bidders):        
        # Example strategy: bid half of my x_i
        
        # return (current_value/2, conf) # return a tuple (bid, confidence) only for variant 2, where a confidence is also needed
        
        return current_value/2 # return a single value (only bid) for variants 1 & 3, as confidence is not required here
        
        